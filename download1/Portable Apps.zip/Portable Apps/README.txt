These apps were provided by HydrogenFire llc & Hydrogen llc.
all credits goto these listed developers:
Aroka (Junior Developer)
Juli (Senior Developer)
Rainy (Senior Developer)
Devil$Flowers (Full Stack Developer)